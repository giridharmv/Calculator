﻿namespace IMainmenu
{
    public class interface
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
