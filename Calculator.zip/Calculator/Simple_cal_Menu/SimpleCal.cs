﻿
namespace Simple_cal_Menu
{
    public class SimpleCal
    {
        public static void SimpleCalculator()
        {
            do
            {
                Menu();

                try
                {
                    short choice = Convert.ToInt16(Console.ReadLine());

                    switch (choice)
                    {
                        // Function algorithm for Addition
                        case 1:
                            Addition();
                            break;
                        // Function algorithm for Substraction 
                        case 2:
                            Subtraction();
                            break;
                        // Function algorithm for Multiplication
                        case 3:
                            Multiplication();
                            break;
                        // Function algorithm for Division
                        case 4:
                            Division();
                            break;
                        case 5:
                            return;
                        default:
                            Console.WriteLine();
                            Console.WriteLine("\"Error: Invalid Input\"");
                            break;
                    }
                }
                // Exception Handling
                catch (DivideByZeroException)
                { Console.WriteLine("Error: Denominator should not be zero. Try again."); }

                catch (OverflowException)
                { Console.WriteLine($"Error: The Choice should be between 1 and 5. Try again"); }

                catch (FormatException)
                { Console.WriteLine($"Error: Enter only Interger Values."); }

                catch (Exception e)
                { Console.WriteLine($"Error: The error is {e}"); }

                Console.WriteLine();
            } while (true);
        }
        public static void Menu()
        {
            Console.WriteLine();
            Console.WriteLine("______You have Entered Simple Calculator______");
            Console.WriteLine("Select the choice to perform: ");
            Console.WriteLine("1.Addition");
            Console.WriteLine("2.Subtraction");
            Console.WriteLine("3.Multiplication");
            Console.WriteLine("4.Division");
            Console.WriteLine("5.Back to Menu");

            Console.Write("Your Choice: ");
        }
        public static void Addition()
        {
            int result=0, num, numberofintegers;
            Console.WriteLine("____Addition____");
            do
            {
                Console.Write("Enter Number of Intergers to Perform Addition: ");
                numberofintegers = Convert.ToInt32(Console.ReadLine());
                if (numberofintegers > 0)
                {
                    for (int i = 1; i <= numberofintegers; i++)
                    {
                        Console.Write($"Enter number {i}: ");
                        num = Convert.ToInt32(Console.ReadLine());
                        result += num;
                    }
                    Console.WriteLine();
                    Console.WriteLine($"The Addition of {numberofintegers} numbers is: {result}");
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("Please Enter positive Integer only.");
                }
            } while (numberofintegers <= 0);

        }
        public static void Subtraction()
        {
            int result, num, numberofintegers;

            Console.WriteLine("____Substraction____");
            do
            {
                Console.Write("Enter Number of Intergers to Perform Substraction: ");
                numberofintegers = Convert.ToInt32(Console.ReadLine());
                if (numberofintegers > 0)
                {
                    Console.Write("Enter Number 0: ");
                    result = Convert.ToInt32(Console.ReadLine());

                    for (int i = 1; i <= numberofintegers - 1; i++)
                    {

                        Console.Write($"Enter number {i}: ");
                        num = Convert.ToInt32(Console.ReadLine());

                        result -= num;
                    }
                    Console.WriteLine();
                    Console.WriteLine($"The Substraction of {numberofintegers} numbers is: {result}");
                    Console.WriteLine();
                }
                else
                    Console.WriteLine("Please Enter positive Integer only.");
            } while (numberofintegers <= 0);
        }
        public static void Multiplication()
        {
            int num, numberofintegers;

            Console.WriteLine("____Multiplication____");
            float mul = 1;
            do
            {
                Console.Write("Enter Number of Intergers to Perform Multiplication: ");
                numberofintegers = Convert.ToInt32(Console.ReadLine());
                if (numberofintegers > 0)
                {
                    for (int i = 1; i <= numberofintegers; i++)
                    {
                        Console.Write($"Enter number {i}: ");
                        num = Convert.ToInt32(Console.ReadLine());
                        mul *= num;
                    }
                    Console.WriteLine();
                    Console.WriteLine($"The Multiplication of {numberofintegers} numbers is: {mul}");
                    Console.WriteLine();
                }
                else
                    Console.WriteLine("Please Enter positive Integer only.");
            } while (numberofintegers <= 0);
        }
        public static void Division()
        {
            int num, numberofintegers;

            Console.WriteLine("____Division____");
            do
            {
                Console.Write("Enter Number of Intergers to Perform Division: ");
                numberofintegers = Convert.ToInt32(Console.ReadLine());
                if (numberofintegers > 0)
                {
                    Console.Write("Enter Number 0: ");
                    float div = Convert.ToInt32(Console.ReadLine());


                    for (int i = 1; i <= numberofintegers - 1; i++)
                    {
                        Console.Write($"Enter number {i}: ");
                        num = Convert.ToInt32(Console.ReadLine());
                        div /= num;
                    }
                    Console.WriteLine();
                    Console.WriteLine($"The Division of {numberofintegers} numbers is: {div}");
                    Console.WriteLine();
                }
                else
                    Console.WriteLine("Please Enter positive Integer only.");
            } while (numberofintegers <= 0);
        }   
        public static void Main(string[] args){}

    }
}
