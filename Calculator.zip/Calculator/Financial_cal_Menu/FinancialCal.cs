﻿using System;

namespace Financial_cal_Menu
{
    public class FinancialCal:IFinancialCal
    {
        public static void FinancialCalculator()
        {
            IFinancialCal Fc = new FinancialCal();

            do
            {
                Menu();
                try
                {

                    short choice = Convert.ToInt16(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            Fc.Percentage();
                            break;
                        case 2:
                            Fc.TipCalculator();
                            break;
                        case 3:
                            Fc.FDCalculator();
                            break;
                        case 4:
                            return;
                    }
                }
                catch (OverflowException o)
                {
                    Console.WriteLine($"Error: The Number should be between 1 && 4. Try again");
                }
                catch (FormatException f)
                {
                    Console.WriteLine($"Error: Enter only Interger Values.");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            } while (true);
        }
        public static void Menu() {
            Console.WriteLine();
            Console.WriteLine("_____Financial Calculator_____");
            Console.WriteLine("1. Percentage");
            Console.WriteLine("2. Tip Calculator");
            Console.WriteLine("3. Fixed Deposit Calculator");
            Console.WriteLine("4. Back to Menu");
            Console.WriteLine();
            Console.Write("Your choice: ");
        }
        //Algo for the all the financial calculations
        public void Percentage()
        {
            float per, num;

            Console.WriteLine("___Percentage___");
            Console.Write("Enter percentage number: ");
            per = Convert.ToSingle(Console.ReadLine());
            if (per < 0)
            {
                Console.WriteLine();
                Console.WriteLine("Percentage should be Greater than 0");
            }
            Console.Write("Calculate Percentage of: ");
            num = Convert.ToInt32(Console.ReadLine());
            if (num < 0)
            {
                Console.WriteLine();
                Console.WriteLine("Number should be Greater than 0");
            }
            Console.WriteLine();
            Console.WriteLine($"The {per}% of {num} is: {(per * num) / 100}");
            Console.WriteLine();
        }
        // Function of Percentage Calculator
        public void TipCalculator()
        {
            char tip;
            short bill, num;
            float total;

            Console.WriteLine("___Tip Calculator___");
            Console.WriteLine("How was the service: Good(G)/Bad(B)?");
            tip = Convert.ToChar(Console.ReadLine());
            Console.Write("Enter the Total bill amount: ");
            bill = Convert.ToInt16(Console.ReadLine());
            Console.Write("Enter the percentage of tip you wish to give: ");
            Console.WriteLine("Suggestion: You can tip between 5% to 14%.");
            if (bill>0 && tip>0) {
                num = Convert.ToInt16(Console.ReadLine());
                if (tip == 'g' || tip == 'G')
                {
                    Console.WriteLine();
                    Console.WriteLine("Great to hear that Service went well!");
                }
                else if (tip == 'b' || tip == 'B')
                {
                    Console.WriteLine();
                    Console.WriteLine("I am sorry to hear that service didn't go as you expected.");
                    Console.WriteLine("Enter the percentage of tip you wish to give: ");
                }
                total = bill + ((bill * num) / 100);
                Console.WriteLine();
                Console.WriteLine($"Tip amount against total bill: {(bill * num) / 100}");
                Console.WriteLine($"Total Amount with tip included: {total}");
            }
            else
            {
                Console.WriteLine("Please enter valid bill and tip percentage.");
            }
        }
        // Function of Tip Calculator
        public void FDCalculator()
        {
            float Lumpsumamount,lumpsum, per, permonth;
            short years,months;
            int i, j;

            Console.WriteLine();
            Console.WriteLine("____Fixed Deposit Calculator____");
            try
            {
                Console.Write("Enter the Lumpsum amount: ");
                Lumpsumamount = Convert.ToSingle(Console.ReadLine());
                lumpsum = Lumpsumamount;
                Console.Write("Enter the Expected returns in Percentage: ");
                per = Convert.ToSingle(Console.ReadLine());
                Console.Write("Enter the Number of Years you want to invest in: ");
                years = Convert.ToInt16(Console.ReadLine());
                Console.Write("Enter the Number of Months you want to invest in: ");
                months = Convert.ToInt16(Console.ReadLine()); 
                permonth = per / 12;
                
                for ( i=1; i<=years; i++)
                {
                    Lumpsumamount = ((Lumpsumamount * per) / 100) + Lumpsumamount;
                }
                for (j = 1; j <= months; j++)
                {
                    Lumpsumamount = ((Lumpsumamount * permonth) / 100) + Lumpsumamount;
                }
                Console.WriteLine($"The Total Lumsum amout you would recieve after {years} years and {months} months is: {Lumpsumamount} in rupees.");
                Console.WriteLine();
                do
                {
                    Console.WriteLine();
                    Console.WriteLine("Do you wish to see every years return statement: Y/N?");
                    string  select= Console.ReadLine();
                    if (select == "y"|| select == "Y")
                    {
                        for (i = 1; i <= years; i++)
                        {
                            lumpsum = ((lumpsum * per) / 100) + lumpsum;
                            Console.WriteLine($"The year {i} for {per} % is: {lumpsum} in rupees.");
                        }
                        for (j = 1; j <= months; j++)
                        {
                            lumpsum = ((lumpsum * permonth) / 100) + lumpsum;
                            Console.WriteLine($"The year {years} and month {j} for {permonth} % for each month: {lumpsum} in rupees.");
                        }
                        break;
                    }
                    else if (select == "n" || select == "N")
                    {
                        Console.WriteLine("Thank you for using Fixed Deposit Calculator.");
                        Console.WriteLine();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Please enter valid input in char (single letter y/n?).");
                    }
                }while (true);
            }
            catch (FormatException)
            {
                Console.WriteLine("Enter Valid Integer only.");
            }
            catch (OverflowException)
            {
                Console.WriteLine($"Enter value between {uint.MinValue} and {uint.MaxValue}.");
            }
            catch(Exception e)
            {
                Console.WriteLine($"The error message is {e}.");
            }
        }
        //Function of Fixed Deposit Calculator
        static void Main()
        {
            FinancialCalculator();
        }
    }
    public interface IFinancialCal
    {
        void Percentage();
        void TipCalculator();
        void FDCalculator();
    }
    // An Interface for Financial Calculator functions
}
