﻿using System;
using Simple_cal_Menu;
using Scientific_cal_Menu;
using Financial_cal_Menu;



namespace Calculator 
{

    public class MainMenu 
    {
        public static void Menu()
        {
            do { 
                Console.WriteLine("________Welcome to Calculator________");
                Console.WriteLine();
                Console.WriteLine("****Select the Feature****");
                Console.WriteLine();
                Console.WriteLine("1. Simple Calculator");
                Console.WriteLine("2. Scientific Calculator");
                Console.WriteLine("3. Financial Calculator");
                Console.WriteLine("4. Exit");
                Console.WriteLine();
                Console.Write("Your Selected feature: ");

                try
                {
                    short choice = Convert.ToInt16(Console.ReadLine());   //Read user feature choice
                    switch (choice)
                    {
                        case 1:
                            SimpleCal.SimpleCalculator();
                            break;
                        case 2:
                            ScientificCal.ScientificCalculator();
                            break;
                        case 3:
                            FinancialCal.FinancialCalculator();
                            break;
                        case 4:
                            return;
                        default:
                            Console.WriteLine();
                            Console.WriteLine("\"Error: Invalid Input\"");
                            break;
                    }
                }
                // Exception Handling
                catch (OverflowException o)
                {
                    Console.WriteLine($"Error: The Number should be between 1 && 3. Try again");
                }
                catch (FormatException f)
                {
                    Console.WriteLine($"Error: Enter only Interger Values.");
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Error: The error is {e}");
                }
                Console.WriteLine();
            }while (true);


        }

        //Functions for different calculators
       
        

        public static void Main(string[] args)
        {
            Menu();
        }



    }
}
