﻿using System;   

namespace Scientific_cal_Menu
{
    public class ScientificCal
    {
        public static void ScientificCalculator()
        {
            short choice;
            do
            {
                Menu();   
                try
                {
                    choice = Convert.ToInt16(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            Trigno();       // Function call that contains all trignometric Methods.
                            break;
                        case 2:
                            Powers_of_Integer();        // Function call that contains Power of a Integer Method.
                            break;
                        case 3:
                            SquareRoot();       // Function call that contains Square Root of a Integer Method.
                            break;
                        case 4:
                            return;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Please Enter only Integer options.");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Please enter the choice between 1 to 4.");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            } while (true);
        }
        public static void Menu()
        {
            Console.WriteLine();
            Console.WriteLine("____Scientific Calculator____");
            Console.WriteLine("1. Trignometry");
            Console.WriteLine("2. Powers of a Integer");
            Console.WriteLine("3. Square Root of a Integer");
            Console.WriteLine("4. Back to Menu");
            Console.WriteLine();
            Console.Write("Your Choice: ");
            Console.WriteLine();
        }
        //Contain all the Menu Specific Options
        public static void Trigno()
        {
            short angle, choice;
            double radians;
            float result;
            Console.WriteLine("___Trignometry___");
            do
            {
                Console.WriteLine("Which Trignometric Function to Perform");
                Console.WriteLine("1. Sine");
                Console.WriteLine("2. Cosine");
                Console.WriteLine("3. Tangent");
                Console.WriteLine("4. Cotangent");
                Console.WriteLine("5. Secant");
                Console.WriteLine("6. Cosecant");
                Console.WriteLine("7. Back to Menu");
                Console.WriteLine();
                Console.Write("Your Choice: ");
                try
                {
                    choice = Convert.ToInt16(Console.ReadLine());
                    Console.WriteLine("Please Enter angle between 0 to 360 degree.");

                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("______SINE______");
                            Console.Write("Enter the Angle Value for calculating Sine: ");
                            angle = Convert.ToInt16(Console.ReadLine());
                            radians = angle * (Math.PI / 180);
                            result = Convert.ToSingle(Math.Sin(radians));
                            Console.WriteLine();
                            Console.WriteLine($"The Value of Sin({angle}) is: {result}");
                            Console.WriteLine();
                            break;
                        case 2:
                            Console.WriteLine("______COSINE______");
                            Console.Write("Enter the Angle Value for calculating Cos: ");
                            angle = Convert.ToInt16(Console.ReadLine());
                            radians = angle * (Math.PI / 180);
                            result = Convert.ToSingle(Math.Cos(radians));
                            Console.WriteLine();
                            Console.WriteLine($"The Value of Cos({angle}) is: {result}");
                            Console.WriteLine();
                            break;
                        case 3:
                            Console.WriteLine("______TANGENT______");
                            Console.Write("Enter the Angle Value for calculating Tan: ");
                            angle = Convert.ToInt16(Console.ReadLine());
                            radians = angle * (Math.PI / 180);
                            result = Convert.ToSingle(Math.Tan(radians));
                            Console.WriteLine();
                            Console.WriteLine($"The Value of Tan({angle}) is: {result}");
                            Console.WriteLine();
                            break;
                        case 4:
                            Console.WriteLine("______COTANGENT______");
                            Console.Write("Enter the Angle Value for calculating Cot: ");
                            angle = Convert.ToInt16(Console.ReadLine());
                            radians = angle * (Math.PI / 180);
                            if (angle==0 || angle==180 || angle==360)
                            {
                                Console.WriteLine();
                                Console.WriteLine($"Cotangent cot({angle}) is Undefined.");
                                Console.WriteLine();
                                break;
                            }
                            else
                            {
                                result = 1 / (Convert.ToSingle(Math.Tan(radians)));
                                Console.WriteLine();
                                Console.WriteLine($"The Value of Cot({angle}) is: {result}");
                                Console.WriteLine();
                            }
                            break;
                        case 5:
                            Console.WriteLine("______SECANT______");
                            Console.Write("Enter the Angle Value for calculating Sec: ");
                            angle = Convert.ToInt16(Console.ReadLine());
                            radians = angle * (Math.PI / 180);
                            if (Math.Cos(radians) == 0 || angle==90 || angle==270)
                            {
                                Console.WriteLine();
                                Console.WriteLine($"Secant sec({angle}) is Undefined.");
                                Console.WriteLine();
                                break;
                            }
                            else
                            {
                                result = 1 / (Convert.ToSingle(Math.Cos(radians)));
                                Console.WriteLine();
                                Console.WriteLine($"The Value of Sec({angle}) is: {result}");
                                Console.WriteLine();
                            }
                            break;
                        case 6:
                            Console.WriteLine("______COSECANT______");
                            Console.Write("Enter the Angle Value for calculating Cosec: ");
                            angle = Convert.ToInt16(Console.ReadLine());
                            radians = angle * (Math.PI / 180);
                            if (Math.Sin(radians) == 0 || angle==180 || angle==360)
                            {
                                Console.WriteLine();
                                Console.WriteLine($"Cosecant Cosec({angle}) is Undefined.");
                                Console.WriteLine();
                                break;
                            }
                            else
                            {
                                result = 1 / (Convert.ToSingle(Math.Sin(radians)));
                                Console.WriteLine();
                                Console.WriteLine($"The Value of Cosec({angle}) is: {result}");
                                Console.WriteLine();
                            }
                            break;
                        case 7:
                            return;
                        default:
                            Console.WriteLine();
                            Console.WriteLine("\"Error: Invalid Choice\"");
                            Console.WriteLine();
                            break;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Please Enter only Integer options.");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Please enter the choice between 1 to 7.");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }while (true);

        }
        // Method of all Trignometric calculations.
        public static void Powers_of_Integer()
        {
            Console.WriteLine("___Powers of a Integer___");
            Console.Write("Please enter the Base value: ");
            short baseValue = Convert.ToInt16(Console.ReadLine());
            Console.Write("Please enter the Power value: ");
            short power = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine();
            Console.Write($"Square of {baseValue} is: {Math.Pow(baseValue, power)}");
            Console.WriteLine();
        }
        // Method of Calculating Power of a Integer base.
        public static void SquareRoot()
        {
            Console.WriteLine("___Square Root of Integer___");
            Console.Write("Please enter the Base value: ");
            short baseValue = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine();
            Console.Write($"Square Root of {baseValue} is: {Math.Sqrt(baseValue)}");
            Console.WriteLine();
        }
        // Method of Calculating Square Root of a Integer.
        public static void Main(){ }
    }
}
